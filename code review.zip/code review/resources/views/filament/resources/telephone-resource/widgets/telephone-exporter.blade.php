<x-filament-widgets::widget>
    <x-filament::section>
        <x-exporter :columns="$this->getPageTableRecords()->all()" title="Telephone"/>
    </x-filament::section>
</x-filament-widgets::widget>
