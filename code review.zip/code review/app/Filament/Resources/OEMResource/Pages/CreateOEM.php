<?php

namespace App\Filament\Resources\OEMResource\Pages;

use App\Filament\Resources\OEMResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOEM extends CreateRecord
{
    protected static string $resource = OEMResource::class;
}
